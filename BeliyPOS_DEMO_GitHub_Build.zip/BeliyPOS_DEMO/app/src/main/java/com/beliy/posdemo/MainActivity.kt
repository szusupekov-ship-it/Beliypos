package com.beliy.posdemo

import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {
    private var nfcAdapter: NfcAdapter? = null
    private var onCardDetected: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        setContent {
            var detected by remember { mutableStateOf(false) }
            var nfcEnabled by remember { mutableStateOf(nfcAdapter?.isEnabled == true) }

            onCardDetected = {
                runOnUiThread {
                    if (!detected) {
                        detected = true
                        try {
                            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                                .startTone(ToneGenerator.TONE_PROP_ACK, 180)
                        } catch (_: Exception) { }
                    }
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF35D07F),
                background = Color(0xFF101713),
                surface = Color(0xFF19231D)
            )) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF101713)
                ) {
                    PosScreen(
                        detected = detected,
                        nfcAvailable = nfcAdapter != null,
                        nfcEnabled = nfcEnabled,
                        onReset = { detected = false },
                        onRefresh = { nfcEnabled = nfcAdapter?.isEnabled == true }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        if (adapter.isEnabled) {
            adapter.enableReaderMode(
                this,
                this,
                NfcAdapter.FLAG_READER_NFC_A or
                    NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or
                    NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS,
                null
            )
        }
    }

    override fun onPause() {
        nfcAdapter?.disableReaderMode(this)
        super.onPause()
    }

    override fun onTagDiscovered(tag: Tag) {
        // Только факт обнаружения NFC-метки/карты.
        // UID и платёжные данные не читаются и не сохраняются.
        onCardDetected?.invoke()
    }
}

@Composable
private fun PosScreen(
    detected: Boolean,
    nfcAvailable: Boolean,
    nfcEnabled: Boolean,
    onReset: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "BELIY POS",
                color = Color.White,
                fontSize = 27.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )
            Text(
                "ДЕМОНСТРАЦИОННЫЙ ТЕРМИНАЛ",
                color = Color(0xFF9EB2A5),
                fontSize = 10.sp,
                letterSpacing = 1.5.sp
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF19271F))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("СУММА", color = Color(0xFF9EB2A5), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "100 ₸",
                    color = Color.White,
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(24.dp))

                Icon(
                    imageVector = Icons.Default.Nfc,
                    contentDescription = "NFC",
                    tint = if (detected) Color(0xFF35D07F) else Color(0xFFB6C7BC),
                    modifier = Modifier.size(76.dp)
                )
                Spacer(Modifier.height(16.dp))

                if (detected) {
                    Text(
                        "NFC ОБНАРУЖЕН",
                        color = Color(0xFF35D07F),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "ДЕМО: ОПЛАТА НЕ ВЫПОЛНЯЛАСЬ",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        "ПРИЛОЖИТЕ NFC-КАРТУ",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Ожидание бесконтактной метки",
                        color = Color(0xFF9EB2A5),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (!nfcAvailable) {
                Text("В этом устройстве NFC не обнаружен", color = Color(0xFFFFB4AB))
            } else if (!nfcEnabled) {
                Text("Включите NFC в настройках телефона", color = Color(0xFFFFD180))
                TextButton(onClick = onRefresh) { Text("Проверить снова") }
            } else {
                Text("NFC готов к обнаружению", color = Color(0xFF9EB2A5))
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onReset,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("СБРОСИТЬ")
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "DEMO ONLY • НЕТ СПИСАНИЯ ДЕНЕГ • НЕ БАНКОВСКИЙ ТЕРМИНАЛ",
                color = Color(0xFF829489),
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
